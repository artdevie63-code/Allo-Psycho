# Mistral UE — activation

Secrets Supabase :

- `MISTRAL_API_KEY` : clé API Mistral.
- `MISTRAL_MODEL` : `mistral-small-2603` (optionnel : c'est déjà la valeur par défaut).

Endpoint utilisé par `ai-support` :

`https://api.eu.mistral.ai/v1/chat/completions`

Après création de la clé, vérifie dans Mistral que `mistral-small-2603` est disponible pour ton organisation sur l'endpoint régional UE. Si Mistral change la disponibilité régionale, il suffit de modifier `MISTRAL_MODEL` dans les Secrets Supabase : aucune clé ni identifiant de modèle ne doit être placé dans le frontend ou GitHub.
