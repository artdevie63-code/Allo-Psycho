import Stripe from "npm:stripe@^22";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    const url = Deno.env.get("SUPABASE_URL");
    const anon = Deno.env.get("SUPABASE_ANON_KEY");
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    const appUrl = (Deno.env.get("APP_URL") || "https://allopsycho.fr").replace(/\/+$/, "");
    const auth = req.headers.get("Authorization") || "";

    if (!url || !anon || !service || !stripeKey) {
      return json({ ok: false, error: "configuration", diagnostic: "SP-CFG" }, 500);
    }

    const userClient = createClient(url, anon, {
      global: { headers: { Authorization: auth } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return json({ ok: false, error: "unauthorized", diagnostic: "SP-AUTH" }, 401);
    }

    const admin = createClient(url, service, { auth: { persistSession: false } });

    const existing = await admin
      .from("stripe_subscriptions")
      .select("stripe_customer_id")
      .eq("user_id", user.id)
      .maybeSingle();

    if (existing.error || !existing.data?.stripe_customer_id) {
      return json({ ok: false, error: "no_subscription", diagnostic: "SP-NONE" });
    }

    const stripe = new Stripe(stripeKey);
    const session = await stripe.billingPortal.sessions.create({
      customer: existing.data.stripe_customer_id,
      return_url: `${appUrl}/?stripe=portal-return`,
    });

    return json({ ok: true, url: session.url });
  } catch (error) {
    console.error("stripe-portal", error);
    return json({
      ok: false,
      error: "server_error",
      diagnostic: "SP-EDGE",
      detail: error instanceof Error ? error.message : "unknown",
    }, 500);
  }
});
