import Stripe from "npm:stripe@^22";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

function periodEndIso(subscription: any): string | null {
  const seconds =
    subscription?.current_period_end ??
    subscription?.items?.data?.[0]?.current_period_end ??
    null;

  return typeof seconds === "number"
    ? new Date(seconds * 1000).toISOString()
    : null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    const url = Deno.env.get("SUPABASE_URL");
    const anon = Deno.env.get("SUPABASE_ANON_KEY");
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    const priceId = Deno.env.get("STRIPE_PRICE_ID");
    const auth = req.headers.get("Authorization") || "";

    if (!url || !anon || !service || !stripeKey) {
      return json({ ok: false, error: "configuration", diagnostic: "SS-CFG" }, 500);
    }

    const userClient = createClient(url, anon, {
      global: { headers: { Authorization: auth } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return json({ ok: false, error: "unauthorized", diagnostic: "SS-AUTH" }, 401);
    }

    const payload = await req.json().catch(() => ({}));
    const sessionId = String(payload.session_id || "").trim();

    if (!sessionId.startsWith("cs_")) {
      return json({ ok: false, error: "invalid_session", diagnostic: "SS-SESSION" }, 400);
    }

    const stripe = new Stripe(stripeKey);
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    const sessionUser =
      session.client_reference_id ||
      session.metadata?.supabase_user_id ||
      "";

    if (sessionUser !== user.id) {
      return json({ ok: false, error: "session_owner_mismatch", diagnostic: "SS-OWNER" }, 403);
    }

    const subscriptionId =
      typeof session.subscription === "string"
        ? session.subscription
        : session.subscription?.id;

    if (!subscriptionId) {
      return json({ ok: false, error: "missing_subscription", diagnostic: "SS-NOSUB" }, 409);
    }

    const subscription: any = await stripe.subscriptions.retrieve(subscriptionId);
    const endIso = periodEndIso(subscription);

    if (!["active", "trialing"].includes(subscription.status) || !endIso) {
      return json({
        ok: false,
        error: "subscription_not_active",
        diagnostic: "SS-INACTIVE",
        status: subscription.status,
      }, 409);
    }

    const admin = createClient(url, service, { auth: { persistSession: false } });
    const customerId =
      typeof subscription.customer === "string"
        ? subscription.customer
        : subscription.customer?.id || null;

    const row = await admin
      .from("stripe_subscriptions")
      .upsert({
        user_id: user.id,
        stripe_customer_id: customerId,
        stripe_subscription_id: subscription.id,
        stripe_price_id:
          subscription.items?.data?.[0]?.price?.id || priceId || null,
        status: subscription.status,
        current_period_end: endIso,
        updated_at: new Date().toISOString(),
      }, { onConflict: "user_id" });

    if (row.error) {
      return json({ ok: false, error: "stripe_state_write", diagnostic: "SS-STATE" }, 500);
    }

    const existing = await admin
      .from("premium_entitlements")
      .select("premium_until")
      .eq("user_id", user.id)
      .maybeSingle();

    if (existing.error) {
      return json({ ok: false, error: "entitlement_read", diagnostic: "SS-ENT-READ" }, 500);
    }

    const current = existing.data?.premium_until
      ? new Date(existing.data.premium_until).getTime()
      : 0;

    const permanent =
      current >= new Date("2099-01-01T00:00:00.000Z").getTime();

    if (!permanent && new Date(endIso).getTime() > current) {
      const update = await admin
        .from("premium_entitlements")
        .update({ premium_until: endIso })
        .eq("user_id", user.id);

      if (update.error) {
        return json({ ok: false, error: "entitlement_write", diagnostic: "SS-ENT-WRITE" }, 500);
      }
    }

    return json({
      ok: true,
      active: true,
      expires_at: permanent ? existing.data?.premium_until : endIso,
      stripe_status: subscription.status,
    });
  } catch (error) {
    console.error("stripe-sync", error);
    return json({
      ok: false,
      error: "server_error",
      diagnostic: "SS-EDGE",
      detail: error instanceof Error ? error.message : "unknown",
    }, 500);
  }
});
