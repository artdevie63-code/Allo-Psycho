import Stripe from "npm:stripe@^22";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const stripeKey = Deno.env.get("STRIPE_SECRET_KEY") || "";
const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET") || "";
const url = Deno.env.get("SUPABASE_URL") || "";
const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
const configuredPriceId = Deno.env.get("STRIPE_PRICE_ID") || "";

const stripe = new Stripe(stripeKey);
const cryptoProvider = Stripe.createSubtleCryptoProvider();

function periodEndIso(subscription: any): string | null {
  const seconds =
    subscription?.current_period_end ??
    subscription?.items?.data?.[0]?.current_period_end ??
    null;

  return typeof seconds === "number"
    ? new Date(seconds * 1000).toISOString()
    : null;
}

function customerIdOf(value: any): string | null {
  return typeof value === "string" ? value : value?.id || null;
}

function subscriptionIdFromInvoice(invoice: any): string | null {
  const candidates = [
    invoice?.subscription,
    invoice?.parent?.subscription_details?.subscription,
    invoice?.subscription_details?.subscription,
  ];

  for (const value of candidates) {
    if (typeof value === "string") return value;
    if (value?.id) return value.id;
  }

  return null;
}

Deno.serve(async (req) => {
  if (!stripeKey || !webhookSecret || !url || !service) {
    console.error("stripe-webhook: missing server configuration");
    return new Response("configuration error", { status: 500 });
  }

  const signature = req.headers.get("stripe-signature") || "";
  const body = await req.text();

  let event: Stripe.Event;

  try {
    event = await stripe.webhooks.constructEventAsync(
      body,
      signature,
      webhookSecret,
      undefined,
      cryptoProvider,
    );
  } catch (error) {
    console.error("stripe-webhook bad signature", error);
    return new Response("bad signature", { status: 400 });
  }

  const admin = createClient(url, service, { auth: { persistSession: false } });

  const already = await admin
    .from("stripe_events")
    .select("event_id")
    .eq("event_id", event.id)
    .maybeSingle();

  if (already.data) {
    return Response.json({ received: true, duplicate: true });
  }

  async function findUserBySubscription(
    subscriptionId: string | null,
    customerId: string | null,
  ): Promise<string | null> {
    if (subscriptionId) {
      const bySub = await admin
        .from("stripe_subscriptions")
        .select("user_id")
        .eq("stripe_subscription_id", subscriptionId)
        .maybeSingle();
      if (bySub.data?.user_id) return bySub.data.user_id;
    }

    if (customerId) {
      const byCustomer = await admin
        .from("stripe_subscriptions")
        .select("user_id")
        .eq("stripe_customer_id", customerId)
        .maybeSingle();
      if (byCustomer.data?.user_id) return byCustomer.data.user_id;
    }

    return null;
  }

  async function extendPremium(userId: string, endIso: string | null) {
    if (!endIso) return;

    const ent = await admin
      .from("premium_entitlements")
      .select("premium_until")
      .eq("user_id", userId)
      .maybeSingle();

    if (ent.error) throw ent.error;

    if (!ent.data) {
      const created = await admin
        .from("premium_entitlements")
        .insert({ user_id: userId })
        .select("premium_until")
        .single();
      if (created.error) throw created.error;
    }

    const current = ent.data?.premium_until
      ? new Date(ent.data.premium_until).getTime()
      : 0;

    const permanent =
      current >= new Date("2099-01-01T00:00:00.000Z").getTime();

    if (permanent) return;

    if (new Date(endIso).getTime() > current) {
      const update = await admin
        .from("premium_entitlements")
        .update({ premium_until: endIso })
        .eq("user_id", userId);

      if (update.error) throw update.error;
    }
  }

  async function syncSubscription(subscription: any, explicitUserId?: string | null) {
    const subId = subscription?.id || null;
    const customerId = customerIdOf(subscription?.customer);
    const userId =
      explicitUserId ||
      subscription?.metadata?.supabase_user_id ||
      (await findUserBySubscription(subId, customerId));

    if (!userId || !subId) {
      console.warn("stripe-webhook: no Supabase user mapping", {
        event: event.type,
        subscription: subId,
        customer: customerId,
      });
      return;
    }

    const endIso = periodEndIso(subscription);
    const status = String(subscription.status || "unknown");

    const state = await admin
      .from("stripe_subscriptions")
      .upsert({
        user_id: userId,
        stripe_customer_id: customerId,
        stripe_subscription_id: subId,
        stripe_price_id:
          subscription?.items?.data?.[0]?.price?.id ||
          configuredPriceId ||
          null,
        status,
        current_period_end: endIso,
        updated_at: new Date().toISOString(),
      }, { onConflict: "user_id" });

    if (state.error) throw state.error;

    if (["active", "trialing"].includes(status)) {
      await extendPremium(userId, endIso);
    }
  }

  try {
    const obj: any = event.data.object;

    switch (event.type) {
      case "checkout.session.completed": {
        const userId =
          obj.client_reference_id ||
          obj.metadata?.supabase_user_id ||
          null;

        const subscriptionId =
          typeof obj.subscription === "string"
            ? obj.subscription
            : obj.subscription?.id;

        if (userId && subscriptionId) {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId);
          await syncSubscription(subscription, userId);
        }
        break;
      }

      case "invoice.paid": {
        let subscriptionId = subscriptionIdFromInvoice(obj);
        const customerId = customerIdOf(obj.customer);

        if (!subscriptionId) {
          const userId = await findUserBySubscription(null, customerId);
          if (userId) {
            const state = await admin
              .from("stripe_subscriptions")
              .select("stripe_subscription_id")
              .eq("user_id", userId)
              .maybeSingle();
            subscriptionId = state.data?.stripe_subscription_id || null;
          }
        }

        if (subscriptionId) {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId);
          await syncSubscription(subscription);
        }
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        await syncSubscription(obj);
        break;
      }

      case "invoice.payment_failed": {
        const subscriptionId = subscriptionIdFromInvoice(obj);
        if (subscriptionId) {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId);
          await syncSubscription(subscription);
        }
        break;
      }

      default:
        break;
    }

    const saved = await admin
      .from("stripe_events")
      .insert({
        event_id: event.id,
        event_type: event.type,
      });

    if (saved.error && !String(saved.error.code || "").includes("23505")) {
      console.warn("stripe event log", saved.error);
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error("stripe-webhook handler", event.type, error);
    return new Response("handler error", { status: 500 });
  }
});
