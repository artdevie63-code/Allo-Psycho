-- Allo Psycho V9.2.0 — Stripe
-- Tables techniques uniquement. Aucune donnée psychologique n'est stockée ici.

create table if not exists public.stripe_subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  stripe_price_id text,
  status text not null default 'unknown',
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists stripe_subscriptions_customer_idx
  on public.stripe_subscriptions(stripe_customer_id);

create index if not exists stripe_subscriptions_subscription_idx
  on public.stripe_subscriptions(stripe_subscription_id);

alter table public.stripe_subscriptions enable row level security;

-- Cette table est utilisée uniquement par les Edge Functions via service role.
revoke all on table public.stripe_subscriptions from anon, authenticated;


create table if not exists public.stripe_events (
  event_id text primary key,
  event_type text not null,
  processed_at timestamptz not null default now()
);

alter table public.stripe_events enable row level security;
revoke all on table public.stripe_events from anon, authenticated;
