# Allo Psycho V9.2.0 — Mistral UE + Stripe

## 1) Mistral
Créer une clé API Mistral puis ajouter dans Supabase > Edge Functions > Secrets :

MISTRAL_API_KEY = ta clé Mistral
MISTRAL_MODEL = mistral-small-2603

La fonction `ai-support` utilise :
- modèle par défaut : `mistral-small-2603` (configurable par `MISTRAL_MODEL`)
- endpoint : `https://api.eu.mistral.ai/v1/chat/completions`
- JSON mode
- vérifier après création de la clé que le modèle apparaît bien dans la liste des modèles disponibles sur l'endpoint UE
- aucun appel direct Mistral depuis le navigateur

Quand la nouvelle IA est validée, `GROQ_API_KEY` peut être supprimée.

## 2) Stripe
Dans Stripe Dashboard :
1. créer le produit « Allo Psycho Premium » ;
2. créer un prix récurrent mensuel de 7,99 EUR ;
3. copier son identifiant `price_...`.

Ajouter dans Supabase > Edge Functions > Secrets :

STRIPE_SECRET_KEY = sk_...
STRIPE_PRICE_ID = price_...
APP_URL = https://allopsycho.fr

Ne jamais mettre la clé Stripe secrète dans GitHub ou dans index.html.

## 3) Base Supabase
Exécuter une seule fois dans SQL Editor :

`supabase/V9.2-STRIPE.sql`

Cela crée :
- `stripe_subscriptions`
- `stripe_events`

RLS est activé et aucun accès navigateur n'est accordé à ces tables.

## 4) Déployer les fonctions
Déployer :
- ai-support
- premium-access
- stripe-checkout
- stripe-portal
- stripe-sync
- stripe-webhook

IMPORTANT : `stripe-webhook` doit accepter les appels Stripe sans JWT Supabase.
Le fichier `supabase/config.toml` contient :
[functions.stripe-webhook]
verify_jwt = false

## 5) Webhook Stripe
Dans Stripe Workbench / Webhooks, créer un endpoint :

https://sqsuqcpmsaqnlfortbhc.supabase.co/functions/v1/stripe-webhook

Événements à envoyer :
- checkout.session.completed
- invoice.paid
- invoice.payment_failed
- customer.subscription.created
- customer.subscription.updated
- customer.subscription.deleted

Copier ensuite le secret `whsec_...` dans Supabase Secrets :

STRIPE_WEBHOOK_SECRET = whsec_...

## 6) Portail client Stripe
Dans Stripe Dashboard > Customer portal, activer le portail et autoriser au minimum :
- mise à jour du moyen de paiement ;
- annulation de l'abonnement.

## 7) Frontend
Déployer le contenu V9.2.0 sur GitHub/Vercel.

Après mise à jour PWA, fermer complètement l'application puis la rouvrir.

## 8) Tests avant mode Live Stripe
Faire tous les tests avec les clés Stripe TEST :
- achat ;
- retour dans l'app ;
- Premium actif ;
- portail client ;
- annulation ;
- renouvellement simulé ;
- paiement échoué ;
- Admin permanent toujours intact ;
- Testeur permanent toujours intact.

Passer ensuite les clés Stripe LIVE uniquement après validation.

## Sécurité
- le webhook vérifie la signature Stripe ;
- aucune clé secrète dans le frontend ;
- aucune donnée psychologique dans les tables Stripe ;
- les accès permanents 2099 Admin/Testeur ne sont jamais rétrogradés par Stripe.
